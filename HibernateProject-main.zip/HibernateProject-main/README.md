Hibenate作業
===

:link: [SQL table create 指令 (google drive)](https://drive.google.com/drive/folders/1bYd0ZsaEBE9_LNI3xLDt9RSJg1HidumI?usp=drive_link "游標顯示")

- main branch -> 專二原生檔案分支(暫定)
- test branch -> 做作業的分支

### 大家各自用從test branch建立一個自己的分支做作業

> :exclamation: 之後在講好的時間再一起merge到test branch :exclamation:<br/>
> <br/>
> :exclamation: 之後在講好的時間再一起merge到test branch :exclamation: <br/>
> <br/>
> :exclamation: 之後在講好的時間再一起merge到test branch :exclamation:<br/>
