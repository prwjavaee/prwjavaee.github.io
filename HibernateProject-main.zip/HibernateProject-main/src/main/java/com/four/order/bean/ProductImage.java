package com.four.order.bean;

public class ProductImage {
	private int imageID;
	private int productID;
	private String imagePath;

	public ProductImage() {

	}

	public ProductImage(int imageID, int productID, String imagePath) {
		super();
		this.imageID = imageID;
		this.productID = productID;
		this.imagePath = imagePath;
	}

	public int getImageID() {
		return imageID;
	}

	public int getProductID() {
		return productID;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImageID(int imageID) {
		this.imageID = imageID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	@Override
	public String toString() {
		return "ProductImage [imageID=" + imageID + ", productID=" + productID + ", imagePath=" + imagePath + "]";
	}
}
